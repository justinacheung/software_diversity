/**
 * Algorithms provided with <b>JGraphT</b>.
 */
package org.jgrapht.alg;
