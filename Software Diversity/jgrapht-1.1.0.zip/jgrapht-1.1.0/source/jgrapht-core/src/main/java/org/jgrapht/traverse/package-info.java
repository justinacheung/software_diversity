/**
 * Graph traversal means.
 */
package org.jgrapht.traverse;
