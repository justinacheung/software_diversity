/**
 * Utilities for vertex cover algorithms.
 */
package org.jgrapht.alg.vertexcover.util;
